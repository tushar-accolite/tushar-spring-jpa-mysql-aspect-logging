package spring.com.assignment1.model;

import java.io.Serializable;

import javax.persistence.*;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@SuppressWarnings("serial")
@Entity
@Table(name="employee")
@JsonSerialize
public class Employee implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pid;
	
	@Column(name="name")
	private String name;

	@Column(name="age")
	private Integer age;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_Id")
	private Address address;
	 

	public Employee()
	{}


	public Employee(Long pid, String name, Integer age, Address address) {
		super();
		this.pid = pid;
		this.name = name;
		this.age = age;
		this.address = address;
	}


	public Long getPid() {
		return pid;
	}


	public void setPid(Long pid) {
		this.pid = pid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "Employee [pid=" + pid + ", name=" + name + ", age=" + age + ", address=" + address + "]";
	}
		
	
}
