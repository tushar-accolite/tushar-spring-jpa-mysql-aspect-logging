package spring.com.assignment1.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import spring.com.assignment1.model.Employee;

public interface EmployeeRepository<E> extends CrudRepository<Employee, Long> {

public final static String employee_order ="Select p from Employee p Join p.address od Where od.pincode = :pincode";
@Query(employee_order)
Employee findByPincode(Integer pincode);
List<Employee> findByName(String name);
}
