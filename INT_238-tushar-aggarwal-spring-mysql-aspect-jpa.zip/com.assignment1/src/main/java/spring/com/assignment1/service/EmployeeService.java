package spring.com.assignment1.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import spring.com.assignment1.model.Employee;
import spring.com.assignment1.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
    EmployeeRepository<Employee> employeeRepository;
	
	@Transactional
	public List<Employee> getAllEmployees()
	{
		List<Employee> emplist = new ArrayList<Employee>();
		for(Employee emp:employeeRepository.findAll())
		{
			emplist.add(emp);
		}
		return emplist;
	}
	
	@Transactional
	public Employee getByPincode(Integer pincode)
	{
		return employeeRepository.findByPincode(pincode);
	}
	
	@Transactional
	public List<Employee> getByName(String name)
	{
		return (List<Employee>) employeeRepository.findByName(name);
	}
	
	@Transactional
	public long getEmployeeCount()
	{
		return employeeRepository.count();
	}
	@Transactional
	public Optional<Employee> getById(Long id)
	{
		return employeeRepository.findById(id);
	}
	
	@Transactional
	public void deleteEmployee(Long id) {
         employeeRepository.deleteById(id);
	}

	@Transactional
	public boolean addEmployee(Employee employee) {
		 return employeeRepository.save(employee) != null;
	}

	@Transactional
	public boolean updateEmployee(Employee employee) {
		return employeeRepository.save(employee) != null;
	}
	
	
}
