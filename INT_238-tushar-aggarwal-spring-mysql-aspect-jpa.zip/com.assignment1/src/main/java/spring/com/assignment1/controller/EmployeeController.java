package spring.com.assignment1.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import spring.com.assignment1.model.Employee;
import spring.com.assignment1.service.EmployeeService;


@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET)
	public @ResponseBody Optional<Employee> getAllUsers(@PathVariable Long id) {
		return employeeService.getById(id);
	}

	@RequestMapping(value = "/employeeByName/{name}", method = RequestMethod.GET)
	public List<Employee> getEmployeeeByName(@PathVariable String name) {
		return employeeService.getByName(name);
	}
    
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public List<Employee> getAll() {
		return employeeService.getAllEmployees();
	}

	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
	public HttpStatus deleteEmployee(@PathVariable Long id) {
		employeeService.deleteEmployee(id);
		return HttpStatus.NO_CONTENT;
	}
    
	@RequestMapping(value = "/employeeByPincode/{pincode}", method = RequestMethod.GET)
	public Employee getEmployeeeByPincode(@PathVariable Integer pincode) {
		return employeeService.getByPincode(pincode);
	}
	
	@RequestMapping(value = "/employee/count", method = RequestMethod.GET)
	public long getEmployeeCount() {
		return employeeService.getEmployeeCount();
    }
	
	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public HttpStatus insertEmployee(@RequestBody Employee employee) {
		System.out.println("GSKGB");
		return employeeService.addEmployee(employee) ? HttpStatus.CREATED : HttpStatus.BAD_REQUEST;
	}

	@RequestMapping(value = "/employee", method = RequestMethod.PUT)
	public HttpStatus updateEmployee(@RequestBody Employee employee) {
		return employeeService.updateEmployee(employee) ? HttpStatus.ACCEPTED : HttpStatus.BAD_REQUEST;
	}

}
