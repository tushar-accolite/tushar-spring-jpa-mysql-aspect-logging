package spring.com.assignment1.model;

import java.io.Serializable;

import javax.persistence.*;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@SuppressWarnings("serial")
@Entity(name="address")
@Table(name = "address")
@JsonSerialize
public class Address implements Serializable{
	
	@Id
	@Column(name="address_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
    @Column(name = "hNo")
    private Integer hNo;
    @Column(name = "streetNo")
	private Integer streetNo;
    @Column(name ="city")
	private String city;
    @Column(name ="pincode")
	private Integer pincode;
    
//    @OneToOne(mappedBy = "address",fetch = FetchType.LAZY)
//    private Employee employee;
    
    public Address()
	{
		
	}
     
    
	public Address(Long id, Integer hNo, Integer streetNo, String city, Integer pincode) {
		this.id = id;
		this.hNo = hNo;
		this.streetNo = streetNo;
		this.city = city;
		this.pincode = pincode;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer gethNo() {
		return hNo;
	}

	public void sethNo(Integer hNo) {
		this.hNo = hNo;
	}

	public Integer getStreetNo() {
		return streetNo;
	}

	public void setStreetNo(Integer streetNo) {
		this.streetNo = streetNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

//	public Employee getEmployee() {
//		return employee;
//	}
//
//	public void setEmployee(Employee employee) {
//		this.employee = employee;
//	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", hNo=" + hNo + ", streetNo=" + streetNo + ", city=" + city + ", pincode="
				+ pincode + "]";
	}

}